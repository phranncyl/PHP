<?php
  // add lesson code here
?>
<main>
  <section class="masthead about-masthead">
    <div>
      <h1>Error Handling</h1>
    </div>
  </section>
  <section class="row content-row">
    <div class="col-12">
      <h2>Let's Handle Some Errors!</h2>
    </div>
    <div class="col-12">
      <div>
        <?php
          // add lesson code here
        ?>
      </div>
      <div>
        <?php
          // add lesson code here
        ?>
      </div>
      <div>
        <?php
          // add lesson code here
        ?>
      </div>
      <div>
        <p>Next let's catch the error for a variable that has yet to be defined!</p>
        <?php
          // add lesson code here
        ?>
      </div>
    </div>
  </section>
</main>
<?php
  // add lesson code here
?>
