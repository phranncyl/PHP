<section class="row cta-row">
  <div class="col-sm-12 col-md-4 col-lg-4 col-left">
    <h3>Some Service</h3>
    <button type="button" class="btn btn-light">Click Here</button>
  </div>
  <div class="col-sm-12 col-md-4 col-lg-4 col-middle">
    <h3>Some Service</h3>
    <button type="button" class="btn btn-primary">Click Here</button>
  </div>
  <div class="col-sm-12 col-md-4 col-lg-4 col-right">
    <h3>Some Service</h3>
    <button type="button" class="btn btn-light">Click Here</button>
  </div>
</section>