    <footer>
      <h5>This is the footer</h5>
    </footer>
  </body>
</html>