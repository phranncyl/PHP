<?php
  // add lesson code here
?>
    <main>
      <section class="masthead">
        <div>
          <h1>Reusing Code</h1>
        </div>
      </section>
      <!-- this is just filler content -->
      <section class="row content-row">
        <div class="col-sm-12 col-md-12 col-lg-12">
          <h2>Section Heading</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Nisi lacus sed viverra tellus in hac habitasse platea dictumst. Tempus urna et pharetra pharetra massa massa. Scelerisque mauris pellentesque pulvinar pellentesque. Habitant morbi tristique senectus et netus et malesuada. Eget velit aliquet sagittis id consectetur purus ut faucibus. Commodo sed egestas egestas fringilla phasellus faucibus. Consequat id porta nibh venenatis cras. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Nisi lacus sed viverra tellus in hac habitasse platea dictumst. Tempus urna et pharetra pharetra massa massa. Scelerisque mauris pellentesque pulvinar pellentesque. Habitant morbi tristique senectus et netus et malesuada. Eget velit aliquet sagittis id consectetur purus ut faucibus. Commodo sed egestas egestas fringilla phasellus faucibus. Consequat id porta nibh venenatis cras. Elementum eu facilisis sed odio morbi. Commodo sed egestas egestas fringilla phasellus. Dictum non consectetur a erat nam. Turpis cursus in hac habitasse. Facilisis mauris sit amet massa vitae tortor condimentum. Odio aenean sed adipiscing diam.</p>
          <p>Consequat id porta nibh venenatis cras. Elementum eu facilisis sed odio morbi. Commodo sed egestas egestas fringilla phasellus. Dictum non consectetur a erat nam. Turpis cursus in hac habitasse. Facilisis mauris sit amet massa vitae tortor condimentum. Odio aenean sed adipiscing diam.</p>
        </div>
      </section>
      <!-- our next section will contain our call to action (cta.php) -->
      <?php
        // add lesson code here
      ?>
    </main>
<?php
  // add lesson code here
?>
