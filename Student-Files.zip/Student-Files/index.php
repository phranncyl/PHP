<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My First PHP Document</title>
    <meta name="description" content="This is the introduction to using PHP">
    <meta name="robots" content="noindex, nofollow">
  </head>
  <body>
    <!-- one thing that is really nice about PHP is that we can inject it anywhere we what to in a document. In order to add PHP we simply need to add the PHP tag. Just like the below example. -->

  </body>
</html>
