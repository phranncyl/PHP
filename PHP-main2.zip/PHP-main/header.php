<style>
ul.top-menu > li > .logout {
margin-top:15px;
}
</style>
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <a href="index.php" class="logo"><b>MotoTaxi Matão</b></a>
      <div class="nav notify-row" id="top_menu">
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <!-- <li><a class="logout" href="login.php">Login</a></li> -->
        </ul>
      </div>
    </header>
