    <aside>
      <div id="sidebar" >

        <ul class="sidebar-menu" >
         <!-- <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p> -->
		  <h5 class='centered'>	</h5> 
		  
		 
          <li class="mt">
            <a class="active" href="index.php">
              <i class="fa fa-dashboard"></i>
              <span>Home</span>
              </a>
          </li>
          <li class="mt">
              <a class="active">
              <i class="fa fa-dashboard"></i>
                <span>Settings</span>
                </a>
            <ul>
              <li><a href="list_user.php"> <i class="fa fa-users"> Users</i></a></li>
               <li><a href="list_driver.php"><i class="fa fa-car"> Drivers</i></a></li>
              <!--<li><a href="list_region.php"><i class="fa fa-map-signs"> Regions</i></a></li>
              <li><a href="list_values.php"><i class="fa fa-money"> Values</i></a></li> -->
            </ul>
          </li>
        </ul>

      </div>
    </aside>
